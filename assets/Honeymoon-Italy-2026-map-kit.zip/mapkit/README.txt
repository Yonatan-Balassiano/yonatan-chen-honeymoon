HONEYMOON ITALY — 5-19 OCTOBER 2026 — MAP KIT
=============================================

WHAT'S HERE
  Honeymoon-Italy-2026-map.kml   <- IMPORT THIS. 109 pins in 7 toggleable layers.
  Honeymoon-Italy-2026-places.csv   Flat list of all 109 pins, one row each.
  map-csv-layers/                   Same data split per layer, if you'd rather
                                    import layers one at a time (better control).

HOW TO GET IT INTO GOOGLE MY MAPS  (2 minutes)
  1. Go to  https://mymaps.google.com   and sign in.
  2. Click  + CREATE A NEW MAP
  3. Click  Import  (under the first layer)
  4. Upload  Honeymoon-Italy-2026-map.kml
  5. Done — the 7 folders arrive as 7 layers you can tick on and off.
  6. Rename the map (click "Untitled map") and share it with each other.

  On your phone: Google Maps app -> Saved -> Maps -> it appears there.
  My Maps is view-only in the mobile app; edit on desktop.

  If the KML import misbehaves, use the CSVs instead: Import a CSV, choose
  Latitude + Longitude as the position columns and Name as the title column.
  One CSV import = one layer, so import the 7 files in map-csv-layers/ one by one.

THE 7 LAYERS
  1  Bases & hotels          where you sleep + the airport
  2  Main plan               the sights and hikes you're actually doing
  3  Parking                 where to leave the car, free options flagged
  4  Food & drink            restaurants, huts, wineries
  5  Rain & cold fallbacks   the indoor/spa plan B for each day
  6  Optional & swaps        things to slot in or drop
  7  Passes & drive stops    the high passes and route decisions

TAGS  (in every pin description, searchable in My Maps)
  #d1 ... #d15    day number.  D1 = Mon 5 Oct  ->  D15 = Mon 19 Oct
  #hike #sight #lake #town #pass #lift #hut #villa #market #boat #photo
  #hotel #parking #free #paid #trailhead #ferry #funicular #airport
  #food #wine #michelin #splurge #lunch #dinner #cicchetti
  #rain #indoor #spa #thermal #optional #fallback #flex #swap
  #booknow #prebook #callfirst #checkhours #confirm
  #closes11Oct #closes12Oct #to18Oct #to2Nov #closedWed #closedTue #closedSun
  #datecritical #weatherdependent #ICERISK #microspikes #ztl #registerplate
  #maxheight210 #dryonly #carryfood #goearly #before9am

ACCURACY NOTE
  Pin coordinates are APPROXIMATE — typically within 100-300 m, enough to see
  the shape of each day and navigate to the right area. Every pin description
  ends with an "Open exact location in Google Maps" link that resolves
  precisely. Use the pin for planning, the link for driving.
